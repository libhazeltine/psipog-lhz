// HopMulList.h: interface for the CHopMulList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOPMULLIST_H__03C2C4BC_B21C_453F_83FF_CDF75B3F3B53__INCLUDED_)
#define AFX_HOPMULLIST_H__03C2C4BC_B21C_453F_83FF_CDF75B3F3B53__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DoubleList.h"

#define HOP_TOO_BIG(x)    ((x) > 1.0e14 || (x) < -1.0e14)
#define HOP_TOO_SMALL(x)  ((x) > -1.0e-14 && (x) < 1.0e-14 && (x) != 0.0)
#define HOP_IS_BAD(x)     (HOP_TOO_BIG(x) || HOP_TOO_SMALL(x))
#define HOP_BIG_NUMBER    (1.0e7)
#define HOP_SMALL_NUMBER  (1.0e-7)

class CHopMulList  
{
public:
	int GetFractionForm();
	int m_FractionForm;
	int SplitNumbers();
	int OptimizeFract();
	int OptimizeBot();
	int OptimizeTop();
	void FullOptimize();
	double Calculate();
	void Divide(CHopMulList *ml);
	void Multiply(CHopMulList *ml);
	void Invert();
	void Divide(double db);
	void Multiply(double db);
	void Optimize();
	CDoubleList m_Top;
	CDoubleList m_Bot;
	CHopMulList();
	virtual ~CHopMulList();
	bool m_IsOptimized;
private:
	int OptimizeListAcross(CDoubleList *list);
};

#endif // !defined(AFX_HOPMULLIST_H__03C2C4BC_B21C_453F_83FF_CDF75B3F3B53__INCLUDED_)
