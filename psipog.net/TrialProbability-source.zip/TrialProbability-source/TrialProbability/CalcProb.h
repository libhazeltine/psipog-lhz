// CalcProb.h: interface for the CCalcProb class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALCPROB_H__6E4D72AC_DDCB_4BC9_98E2_662CE9ED6590__INCLUDED_)
#define AFX_CALCPROB_H__6E4D72AC_DDCB_4BC9_98E2_662CE9ED6590__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//
//
//  Data structure to pass to the calculating thread
//
//

class CCalcProb  
{
public:
	volatile int m_PercentDone;
	volatile int m_Status;
	volatile BOOL m_Cancel;
	double result;
	BOOL is_range;
	int h_end;
	int h;
	int s;
	double p;
};

#endif // !defined(AFX_CALCPROB_H__6E4D72AC_DDCB_4BC9_98E2_662CE9ED6590__INCLUDED_)
