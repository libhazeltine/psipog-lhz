#if !defined(AFX_IGNOREFOCUSBUTTON_H__60743E11_AF7F_4B11_930F_4DD554190B0D__INCLUDED_)
#define AFX_IGNOREFOCUSBUTTON_H__60743E11_AF7F_4B11_930F_4DD554190B0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IgnoreFocusButton.h : header file
//

//
//  it may seem weird to have a class like this...
//
//  my anal retentive nature led me to think that when the user pushes on the
//  question mark button to prompt for the odds, that when the user returns,
//  the focus shouldn't be on the question mark button.
//
//  if the user hits Cancel on the dialog, then it should focus to the
//  previously focused window.
//
//  if the user hits OK and the previous window is the Odds text field, then
//  it should set the focus to the Trials text field.
//
//  to satisfy my anal retentive nature, I had to create this class to capture
//  the previous focused window when the user hit the ? button.  I also had to
//  add some bizarre code in the OnPromptProb function in CTrialProbabilityDlg.
//
//  oh well.
//

/////////////////////////////////////////////////////////////////////////////
// CIgnoreFocusButton window

class CIgnoreFocusButton : public CButton
{
// Construction
public:
	CIgnoreFocusButton();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIgnoreFocusButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	bool m_EnableCatch;
	HWND m_OldFocus;
	virtual ~CIgnoreFocusButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CIgnoreFocusButton)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IGNOREFOCUSBUTTON_H__60743E11_AF7F_4B11_930F_4DD554190B0D__INCLUDED_)
