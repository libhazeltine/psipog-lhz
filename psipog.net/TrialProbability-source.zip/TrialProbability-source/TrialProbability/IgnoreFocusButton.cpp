// IgnoreFocusButton.cpp : implementation file
//

#include "stdafx.h"
#include "TrialProbability.h"
#include "IgnoreFocusButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIgnoreFocusButton

CIgnoreFocusButton::CIgnoreFocusButton()
{
	m_OldFocus = NULL;
	m_EnableCatch = true;
}

CIgnoreFocusButton::~CIgnoreFocusButton()
{
}


BEGIN_MESSAGE_MAP(CIgnoreFocusButton, CButton)
	//{{AFX_MSG_MAP(CIgnoreFocusButton)
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIgnoreFocusButton message handlers

void CIgnoreFocusButton::OnSetFocus(CWnd* pOldWnd) 
{
	CButton::OnSetFocus(pOldWnd);

	if (pOldWnd != NULL && m_EnableCatch)
		m_OldFocus = pOldWnd->m_hWnd;
}
