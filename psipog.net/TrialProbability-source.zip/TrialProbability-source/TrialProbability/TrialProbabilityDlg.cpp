// TrialProbabilityDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TrialProbability.h"
#include "TrialProbabilityDlg.h"
#include "PromptProbDlg.h"
#include "PreciseNumber.h"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnFormula();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnFormula)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrialProbabilityDlg dialog

CTrialProbabilityDlg::CTrialProbabilityDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTrialProbabilityDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTrialProbabilityDlg)
	m_Hits = _T("");
	m_Odds = _T("");
	m_Trials = _T("");
	m_HitsEnd = _T("");
	m_Range = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTrialProbabilityDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrialProbabilityDlg)
	DDX_Control(pDX, IDC_STATICSPIN, m_StaticSpin);
	DDX_Control(pDX, IDC_STATICPERC, m_StaticPerc);
	DDX_Control(pDX, IDC_STATIC5, m_Static5);
	DDX_Control(pDX, IDC_STATIC4, m_Static4);
	DDX_Control(pDX, IDC_STATIC3, m_Static3);
	DDX_Control(pDX, IDC_STATIC2, m_Static2);
	DDX_Control(pDX, IDC_STATIC1, m_Static1);
	DDX_Control(pDX, IDOK, m_CalcCtrl);
	DDX_Control(pDX, IDC_RANGE, m_RangeCtrl);
	DDX_Control(pDX, IDC_HUH, m_HuhCtrl);
	DDX_Control(pDX, IDC_HITS, m_HitsCtrl);
	DDX_Control(pDX, IDC_ABOUT, m_AboutCtrl);
	DDX_Control(pDX, IDC_TRIALS, m_TrialsCtrl);
	DDX_Control(pDX, IDC_ODDS, m_OddsCtrl);
	DDX_Control(pDX, IDC_PROMPTPROB, m_IgnoreFocusButton);
	DDX_Control(pDX, IDC_HIT2, m_HitsEndCtrl);
	DDX_Text(pDX, IDC_HITS, m_Hits);
	DDV_MaxChars(pDX, m_Hits, 30);
	DDX_Text(pDX, IDC_ODDS, m_Odds);
	DDV_MaxChars(pDX, m_Odds, 30);
	DDX_Text(pDX, IDC_TRIALS, m_Trials);
	DDV_MaxChars(pDX, m_Trials, 30);
	DDX_Text(pDX, IDC_HIT2, m_HitsEnd);
	DDV_MaxChars(pDX, m_HitsEnd, 30);
	DDX_Check(pDX, IDC_RANGE, m_Range);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTrialProbabilityDlg, CDialog)
	//{{AFX_MSG_MAP(CTrialProbabilityDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDOK, OnCalculate)
	ON_BN_CLICKED(IDC_RANGE, OnRangeChange)
	ON_BN_CLICKED(IDC_PROMPTPROB, OnPromptProb)
	ON_BN_CLICKED(IDC_HUH, OnHuh)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrialProbabilityDlg message handlers

BOOL CTrialProbabilityDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	//SetIcon(m_hIcon, FALSE);		// Set small icon
	m_CalcProb = NULL;
	m_StaticPerc.SetWindowText("");
	m_StaticSpin.SetWindowText("");

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTrialProbabilityDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTrialProbabilityDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTrialProbabilityDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTrialProbabilityDlg::OnAbout() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

//
//  OnCalculate is the meat of the program.  Although CPreciseNumber plays an
//  important role, OnCalculate puts it to use to actually spit out the
//  numbers you see on the screen.
//
//  The formulas used are based on this book I read :-).
//
//  Discrete-Event System Simulation, 3rd Edition
//   by Jerry Banks, John S. Carson II, Barry L. Nelson, David M. Nicol
//   Prentice Hall, New Jersey
//   ISBN 0-13-088702-1
//   pages 165 to 167
//
//  In it, they discuss Bernoulli trials and the Binomial distribution.  It's
//  a little complicated, but I stared at it for about four hours and read it
//  a bunch, and finally convinced myself that they are right :-).
//
//  The formula is (in fixed-width ASCII art):
//
//                  / S \      H    M
//   prob(H)   =   |     |   p    q
//                  \ H /
//
//  Where:
//    S = total number of trials
//    p = odds of a successful trial
//    q = odds of a failing trial = 1 - p
//    H = number of hits
//    M = number of misses = S - H
//
//  That's supposed to be big parenthesis on the left and right of the S and H.
//  It means combination, i.e.:
//
//   / S \             S!               S!
//  |     |   =   -------------   =   -------
//   \ H /         H! (S - H)!         H! M!
//
//  The exclaimation point means "factorial".  Basically, multiply the numbers
//  from the starting point back down to 1.  I.e., 5! = 5 * 4 * 3 * 2 * 1.
//  As a rule, 0! = 1.
//
//  So, our final formula is:
//
//                       H    M
//                 S!  p    q
//  prob(H)   =   --------------
//                     H! M!
//
//  The book also has a shortcut for standard deviation in this distribution,
//  which is given by the function:  StdDev = sqrt( S * p * q )
//  They gave a bunch of reasons for it, and after another hour of staring at
//  it, I also agreed with their reasoning.
//
//  OnCalculate just applies this formula based on the input.  It's actually
//  pretty simple in theory.
//
//  The main problem with this entire program was the fact that factorials and
//  exponents will generate big numbers.  The prob(H) function will return a
//  value between 0.0 and 1.0 (because it's a probability), but the calculation
//  can turn out to be a big pain in the ass when S is really big.
//
//  This is because S! grows quick as hell.  1000! = 1000 * 999 * 998 * ...
//  You can see how this turns into a problem.
//
//  But since we know that our eventual answer is between 0.0 and 1.0, then we
//  can suspect there is a better way to calculate it all without having an
//  overflow from the factorial and exponents.  This is where CPerciseNumber
//  comes into play.
//
//  CPreciseNumber was created to intelligently perform the operations of the
//  prob(H) function in such a way that we never overflow or underflow.  So
//  instead of just calculating the raw data with doubles, we tell
//  CPreciseNumber exactly what we want to do, and CPreciseNumber will find a
//  more cleaner way to calculate the final result.
//
//  As it turns out, not only does this avoid over/underflow perfectly, it also
//  runs pretty fast for large numbers.
//
//  Check the source of PreciseNumber.cpp for information on how these
//  optimizations take place.
//

DWORD WINAPI CalcThreadProc(LPVOID lpParameter)
{
	CCalcProb *calc = (CCalcProb *)lpParameter;

	int s = calc->s;
	int h = calc->h;
	int h_end = calc->h_end;
	double p = calc->p;
	int m = s - h;
	int i;
	double q = 1.0 - p;
	CString str;
	CPreciseNumber curOdds(1.0);
	CPreciseNumber totalOdds(0.0);

	if (calc->h_end == calc->h && calc->is_range == TRUE)
		calc->is_range = FALSE;

	//  a small optimization exists here... it's based on the fact
	//  that S! / H!  will simplify because all of the H! will
	//  cancel out with the end of the S!.  For example, suppose
	//  that S = 5 and H = 3:
	//
	//   S!       5 * 4 * 3 * 2 * 1
	//  ----  =  -------------------  =  5 * 4
	//   H!           3 * 2 * 1
	//
	//  the numbers cancel out quite a bit, especially when you
	//  have 1000! / 995!  = 1000 * 999 * 998 * 997 * 996
	//
	//  this optimization is used below.  CPreciseNumber would
	//  correctly handle it, but why even let it get that far when
	//  we can nip it in the butt right here.

	for (i = s; i >= 2; i--)
	{
		if (calc->is_range == FALSE)
			calc->m_PercentDone = 80 * (s - i) / s;
		else
			calc->m_PercentDone = 20 * (s - i) / s;
		if (calc->m_Cancel == TRUE)
		{
			calc->m_Status = 2;
			return 0;
		}
		if (i > h) // add S!/H!
			curOdds.Multiply((double)i);
		if (i <= m) // add 1/M!
			curOdds.Divide((double)i);
		Sleep(0);
	}
	for (i = 1; i <= h; i++) // add p^H
	{
		if (calc->is_range == FALSE)
			calc->m_PercentDone = 80 + 10 * i / h;
		else
			calc->m_PercentDone = 20 + 5 * i / h;
		if (calc->m_Cancel == TRUE)
		{
			calc->m_Status = 2;
			return 0;
		}
		curOdds.Multiply(p);
		Sleep(0);
	}
	for (i = 1; i <= m; i++) // add q^M
	{
		if (calc->is_range == FALSE)
			calc->m_PercentDone = 90 + 9 * i / m;
		else
			calc->m_PercentDone = 25 + 5 * i / m;
		if (calc->m_Cancel == TRUE)
		{
			calc->m_Status = 2;
			return 0;
		}
		curOdds.Multiply(q);
		Sleep(0);
	}
	curOdds.Multiply(100.0); // so that we see percentage in result

	if (calc->is_range == FALSE)
	{
		calc->result = curOdds.Calculate();
		calc->m_PercentDone = 100;
		calc->m_Status = 1;
		return 0;
	}
	
	calc->m_PercentDone = 30;
	totalOdds.Add(curOdds);

	//
	//  to go over a range, all we do is sum up the probability
	//  for each value of H inside that range.  so, the idea is:
	//
	//  prob(start <= H <= end) =
	//     prob(start) + prob(start+1) + prob(start+2) + ....
	//          
	//  simple idea.  but the small trick is that given prob(H),
	//  we can quickly calculate prob(H + 1).  we don't have to
	//  recalculate the entire factorial and exponent crap.
	//
	//  look at the original function:
	//
	//                         H    M
	//                   S!  p    q
	//   prob(H)   =   ------------------
	//                       H!  M!
	//
	//   now, assume H' = H + 1.  remember that M is based on H,
	//   so now we have M' = S - H' = S - H - 1
	//
	//
	//                         H'   M'
	//                   S!  p    q
	//   prob(H')  =   ------------------
	//                       H'!  M'!
	//
	//
	//   replace it with our old values:
	//
	//                         (H + 1)   (S - H - 1)
	//                   S!  p         q
	//   prob(H')  =   -------------------------------
	//                      (H + 1)!  (S - H - 1)!
	//
	//   now factor out prob(H):
	//
	//                   H   (S - H)
	//              S! p   q              p (S - H)
	//   prob(H') = ----------------  *  -----------
	//                 H! (S - H)!        q (H + 1)
	//
	//
	//                         p M               p (S - H' + 1)
	//   prob(H') = prob(H) * ----- = prob(H) * ----------------
	//                         q H'                   q H'
	//
	//
	//   tada!!!  and who says algebra is useless?
	//
	//   this optimization is applied in the loop below:
	//

	for (int cur_h = h + 1; cur_h <= h_end; cur_h++)
	{
		calc->m_PercentDone = 30 + 69 * (cur_h - h) / (h_end - h);
		if (calc->m_Cancel == TRUE)
		{
			calc->m_Status = 2;
			return 0;
		}

		// H' = cur_h
		// curOdds = prob(H)
		curOdds.Multiply(p); // add a p to the top
		curOdds.Divide(q);   // remove a q from the top
		curOdds.Divide((double)cur_h); // add an H' to the bot
		curOdds.Multiply((double)(s - cur_h + 1)); // remove an M from the bot
		totalOdds.Add(curOdds);
		Sleep(0);
	}

	calc->result = totalOdds.Calculate();
	calc->m_PercentDone = 100;
	calc->m_Status = 1;
	
	return 0;
} 

void CTrialProbabilityDlg::OnCalculate() 
{
	if (m_CalcProb != NULL) // already calculating, hit cancel
	{
		m_CalcProb->m_Cancel = TRUE;
		m_CalcCtrl.EnableWindow(FALSE);
		m_CalcCtrl.SetWindowText("Canceling...");
		return;
	}

	UpdateData(TRUE);
	if (m_Odds.IsEmpty())
	{
		AfxMessageBox("Must enter odds.  For help, click on the ? button.");
		return;
	}
	if (m_Trials.IsEmpty())
	{
		AfxMessageBox("Must enter number of trials.");
		return;
	}
	if (m_Hits.IsEmpty())
	{
		AfxMessageBox("Must enter number of hits.");
		return;
	}	
	double p = atof(m_Odds);
	int s = atoi(m_Trials);
	int h = atoi(m_Hits);
	int h_end = atoi(m_HitsEnd);

	if (p < 0.0 || p > 1.0)
		AfxMessageBox("The odds must be between 0 and 1.");
	else if (s <= 0)
		AfxMessageBox("Number of trials must be greater than 0.");
	else if (h < 0)
		AfxMessageBox("Number of hits must be at least 0.");
	else if (h > s)
		AfxMessageBox("You can't have more hits than trials.");
	else
	{
		if (m_Range)
		{
			if (m_HitsEnd.IsEmpty())
			{
				AfxMessageBox("Must enter range of hits.");
				return;
			}
			if (h_end < 0 || h_end > s)
			{
				AfxMessageBox("Illegal range.");
				return;
			}
		}

		if (m_Range && h_end < h)
		{
			int temp = h;
			h = h_end;
			h_end = temp;
		}

		m_OddsCtrl.EnableWindow(FALSE);
		m_IgnoreFocusButton.EnableWindow(FALSE);
		m_TrialsCtrl.EnableWindow(FALSE);
		m_HitsCtrl.EnableWindow(FALSE);
		m_HitsEndCtrl.EnableWindow(FALSE);
		m_RangeCtrl.EnableWindow(FALSE);
		m_AboutCtrl.EnableWindow(FALSE);
		m_HuhCtrl.EnableWindow(FALSE);
		m_Static1.EnableWindow(FALSE);
		m_Static2.EnableWindow(FALSE);
		m_Static3.EnableWindow(FALSE);
		m_Static4.EnableWindow(FALSE);
		m_Static5.EnableWindow(FALSE);
		m_CalcCtrl.SetWindowText("Cancel");

		m_CalcProb = new CCalcProb();
		m_CalcProb->p = p;
		m_CalcProb->s = s;
		m_CalcProb->h = h;
		m_CalcProb->h_end = h_end;
		m_CalcProb->is_range = m_Range;
		m_CalcProb->m_Cancel = FALSE;
		m_CalcProb->m_Status = 0;
		m_CalcProb->m_PercentDone = 0;
		DWORD dummy;

		// we close the handle because of stupid windows:
		// "The thread object remains in the system until the thread has
		//  terminated and all handles to it have been closed through a call
		//  to CloseHandle."
		CloseHandle(CreateThread(NULL, 0, CalcThreadProc, m_CalcProb, 0, &dummy));
		SetTimer(1, 100, NULL);
	}
}

void CTrialProbabilityDlg::OnRangeChange() 
{
	UpdateData(TRUE);
	if (m_Range)
		m_HitsEndCtrl.EnableWindow(TRUE);
	else
		m_HitsEndCtrl.EnableWindow(FALSE);
}

void CAboutDlg::OnFormula() 
{
	::MessageBox(m_hWnd,
"Based on the formulas:\r\n\
prob = ( S! * p^H * q^M ) / ( H! * M! )\r\n\
stdv = sqrt( S * p * q )\r\n\
Where:\r\n\
S = Number of Trials\r\n\
p = Odds of success\r\n\
q = Odds of failure (1 - p)\r\n\
H = Number of hits\r\n\
M = Number of misses (S - H)\r\n\
!  = factorial\r\n\
^ = exponent\r\n", "Formulas", MB_OK | MB_ICONINFORMATION);
}

void CTrialProbabilityDlg::OnPromptProb() 
{
	//
	//  this strange window code is attributed to my anal retentive nature to
	//  have the window focus act precisely as I want.  check the notes in
	//  IgnoreFocusButton.h for more details.
	//
	m_IgnoreFocusButton.m_EnableCatch = false;
	CPromptProbDlg dlg;
	if (dlg.DoModal() == IDOK)
	{
		UpdateData(TRUE);
		m_Odds.Format("%.20g", dlg.m_Result);
		if (m_IgnoreFocusButton.m_OldFocus == m_OddsCtrl.m_hWnd)
			m_IgnoreFocusButton.m_OldFocus = m_TrialsCtrl.m_hWnd;
		UpdateData(FALSE);
	}
	
	if (m_IgnoreFocusButton.m_OldFocus != NULL)
		::SetFocus(m_IgnoreFocusButton.m_OldFocus);
	m_IgnoreFocusButton.m_EnableCatch = true;
}

void CTrialProbabilityDlg::OnHuh() 
{
	::MessageBox(m_hWnd,
"The formulas used in this program are based on the assumption\r\n\
that the trials are independant of each other.  This means that\r\n\
previous trials can't influence the outcome of future trials.  For\r\n\
example, coin flipping and rolling dice is independant.  On the\r\n\
other hand, picking random cards out of a deck and not replacing\r\n\
them is DEPENDANT.  Once a card is picked, it's impossible to\r\n\
pick it again.  To make this independant would require you to\r\n\
replace the chosen card after every trial.",
"Be Aware", MB_OK | MB_ICONINFORMATION);
}

void CTrialProbabilityDlg::OnTimer(UINT nIDEvent) 
{
	static char spinChar[2] = {'<', 0};
	if (nIDEvent == 1 && m_CalcProb != NULL) // checking status of calculation
	{
		if (m_CalcProb->m_Status == 0) // still calculating
		{
			if (spinChar[0] == '<')
				spinChar[0] = '^';
			else if (spinChar[0] == '^')
				spinChar[0] = '>';
			else if (spinChar[0] == '>')
				spinChar[0] = 'v';
			else if (spinChar[0] == 'v')
				spinChar[0] = '<';
			else
				spinChar[0] = '|';

			CString str;
			str.Format("%d%%", m_CalcProb->m_PercentDone);
			m_StaticPerc.SetWindowText(str);
			m_StaticSpin.SetWindowText(spinChar);
		}
		else
		{
			KillTimer(1);
			CString str;
			if (m_CalcProb->m_Status == 1) // finished
			{
				double stdev = sqrt(((double)m_CalcProb->s) * m_CalcProb->p * (1.0 - m_CalcProb->p));
				str.Format("There is a %g percent chance\r\nof this happening randomly.\r\n\r\n(StdDev = %g)",
					m_CalcProb->result, stdev);
			}

			delete m_CalcProb;
			m_CalcProb = NULL;
			
			m_OddsCtrl.EnableWindow(TRUE);
			m_IgnoreFocusButton.EnableWindow(TRUE);
			m_TrialsCtrl.EnableWindow(TRUE);
			m_HitsCtrl.EnableWindow(TRUE);
			if (m_Range == TRUE)
				m_HitsEndCtrl.EnableWindow(TRUE);
			m_RangeCtrl.EnableWindow(TRUE);
			m_AboutCtrl.EnableWindow(TRUE);
			m_HuhCtrl.EnableWindow(TRUE);
			m_Static1.EnableWindow(TRUE);
			m_Static2.EnableWindow(TRUE);
			m_Static3.EnableWindow(TRUE);
			m_Static4.EnableWindow(TRUE);
			m_Static5.EnableWindow(TRUE);

			m_CalcCtrl.EnableWindow(TRUE);
			m_CalcCtrl.SetWindowText("Calculate");
			m_StaticPerc.SetWindowText("");
			m_StaticSpin.SetWindowText("");
			if (!str.IsEmpty())
				::MessageBox(m_hWnd, str, "Results", MB_OK | MB_ICONINFORMATION);
		}
	}
	
	CDialog::OnTimer(nIDEvent);
}
