// HopMulList.cpp: implementation of the CHopMulList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrialProbability.h"
#include "HopMulList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHopMulList::CHopMulList()
{
	m_IsOptimized = true;
	m_FractionForm = 0; // 0 = unknown
}

CHopMulList::~CHopMulList()
{

}

void CHopMulList::Optimize()
{
	if (m_IsOptimized)
		return;

	//
	//  the goal for optimization is to combine as many numbers as possible
	//  so that each individual number is "good", and that any additional
	//  operations would make the result "bad".  this is done by applying a
	//  few mathmatical tricks.  overall, the entire calculated value will be
	//  the same (mathmatically), but the re-organization of operations should
	//  produce a more accurate computation for the final value.
	//
	//  this is done in a few steps.  the first step is to split all "bad"
	//  numbers into "good" counter parts.  this works under the principal that
	//  it's better to have 10 good numbers than 1 bad number.
	//
	//  the next step is to simplify the division as much as possible.  this
	//  compares the values on the top and bottom of the fraction to see what
	//  can be computed safely.  once a safe computation is found, the division
	//  is performed, and the result is stored back into the fraction.
	//
	//  the next two steps are the same - they compare the values across and
	//  figure out what can be multiplied safely.  the safe multiplications
	//  are computed and the new result is saved back into the fraction.
	//

	int t = SplitNumbers();
	t += OptimizeFract();
	t += OptimizeTop();
	t += OptimizeBot();
	if (t == 0) // no optimization took place
		m_IsOptimized = true;
}

void CHopMulList::Multiply(double db)
{
	m_Top.AddTail(db);
	m_IsOptimized = false;
	m_FractionForm = 0;
}

void CHopMulList::Multiply(CHopMulList *ml)
{
	POSITION p = ml->m_Top.GetHeadPosition();
	while (p != NULL)
		Multiply(ml->m_Top.GetNext(p));
	p = ml->m_Bot.GetHeadPosition();
	while (p != NULL)
		Divide(ml->m_Bot.GetNext(p));
	m_IsOptimized = false;
	m_FractionForm = 0;
}

void CHopMulList::Divide(double db)
{
	m_Bot.AddTail(db);
	m_IsOptimized = false;
	m_FractionForm = 0;
}

void CHopMulList::Divide(CHopMulList *ml)
{
	POSITION p = ml->m_Top.GetHeadPosition();
	while (p != NULL)
		Divide(ml->m_Top.GetNext(p));
	p = ml->m_Bot.GetHeadPosition();
	while (p != NULL)
		Multiply(ml->m_Bot.GetNext(p));
	m_IsOptimized = false;
	m_FractionForm = 0;
}

void CHopMulList::Invert()
{
	// Temp = Top
	CDoubleList temp;
	while (!m_Top.IsEmpty())
		temp.AddTail(m_Top.RemoveHead());

	// Top = Bot
	while (!m_Bot.IsEmpty())
		m_Top.AddTail(m_Bot.RemoveHead());

	// Bot = temp
	while (!temp.IsEmpty())
		m_Bot.AddTail(temp.RemoveHead());

	// invert fraction form, if known
	if (m_FractionForm != 0)
	{
		if (m_FractionForm == 1)
			m_FractionForm = 2;
		else
			m_FractionForm = 1;
	}
}

int GetDoubleExponent(double db)
{
	ASSERT(sizeof(int) == 4);

	BYTE *byt = (BYTE *)&db;
	int ret;
	unsigned int *uret = (unsigned int *)&ret;
	if (byt[7] & 0x40) // if negative exponent
		*uret = 0xFFFFF800; // leave 11 bits open
	else // else if positive exponent
		*uret = 0x00000000;
	*uret |= ((int)(byt[7] & 0x7F)) << 4;
	*uret |= ((int)(byt[6] & 0xF0)) >> 4;
	return ret;
}

double CHopMulList::Calculate()
{
	double ret = 1.0;
	double new_val;
	double new_val2;

	POSITION mul_pos = m_Top.GetHeadPosition();
	POSITION div_pos = m_Bot.GetHeadPosition();

	while (mul_pos != NULL || div_pos != NULL)
	{
		if (mul_pos != NULL && div_pos != NULL)
		{
			new_val = ret * m_Top.GetAt(mul_pos);
			if (HOP_IS_BAD(new_val))
			{
				new_val2 = ret / m_Bot.GetAt(div_pos);
				if (HOP_IS_BAD(new_val2))
				{
					// both options suck, figure out which one is worse
					int e1 = GetDoubleExponent(new_val);
					int e2 = GetDoubleExponent(new_val2);
					if (e1 < 0)
						e1 = -e1;
					if (e2 < 0)
						e2 = -e2;
					if (e1 > e2)
					{
						ret = new_val2;
						m_Bot.GetNext(div_pos);
					}
					else
					{
						ret = new_val;
						m_Top.GetNext(mul_pos);
					}
				}
				else
				{
					ret = new_val2;
					m_Bot.GetNext(div_pos);
				}
			}
			else
			{
				ret = new_val;
				m_Top.GetNext(mul_pos);
			}
		}
		else
		{
			if (mul_pos != NULL)
				ret = ret * m_Top.GetNext(mul_pos);
			else
				ret = ret / m_Bot.GetNext(div_pos);
		}
	}

	return ret;
}

void CHopMulList::FullOptimize()
{
	while (!m_IsOptimized)
		Optimize();
}

int CHopMulList::OptimizeTop()
{
	return OptimizeListAcross(&m_Top);
}

int CHopMulList::OptimizeBot()
{
	return OptimizeListAcross(&m_Bot);
}

int CHopMulList::OptimizeListAcross(CDoubleList *list)
{
	//
	//   this optimization trick relies on the fact that:
	//   a * b * c * d * e * f = (a * e * f) * (b * c) * d
	//   we can group the multiplications in ANY order we want... so we
	//   choose to do so intelligently.  we group them and perform the
	//   multiplication ONLY WHEN the result is still in the "good" range.
	//   if the result is bad, then we don't perform that grouping.
	//

	CDoubleList mul_groups;
	double mul;
	double sub_mul;
	bool added_to_mul;
	POSITION p = list->GetHeadPosition();
	POSITION q;
	POSITION last_q = NULL;
	int ret = 0;
	while (p != NULL)
	{
		mul = list->GetNext(p);

		// find a group for mul to be in
		// first check the last used group
		added_to_mul = false;
		if (last_q != NULL)
		{
			sub_mul = mul_groups.GetAt(last_q) * mul;
			if (!HOP_IS_BAD(sub_mul))
			{
				mul_groups.SetAt(last_q, sub_mul);
				added_to_mul = true;
				ret = 1; // some optimization took place
			}
		}
		q = mul_groups.GetHeadPosition();
		while (q != NULL && !added_to_mul)
		{
			sub_mul = mul_groups.GetAt(q) * mul;
			if (!HOP_IS_BAD(sub_mul))
			{
				// found a good group!
				mul_groups.SetAt(q, sub_mul);
				added_to_mul = true;
				last_q = q;
				ret = 1; // some optimization took place
				break;
			}
			mul_groups.GetNext(q);
		}
		// if we can't find a group, add one
		if (!added_to_mul)
			mul_groups.AddTail(mul);
	}

	list->RemoveAll();
	while (!mul_groups.IsEmpty())
		list->AddTail(mul_groups.RemoveHead());

	return ret;
}

int CHopMulList::OptimizeFract()
{
	//
	//   this optimization trick relies on the fact that:
	//   (a * b * c * d) / (e * f * g) = (a / f) * b * (c / e) * (d / g)
	//   since we can group the divisions to any of the numbers on the top
	//   of the fraction, we can wisely choose which divisions to make
	//   based on checking to see if the result is "good".
	//

	// if the top is empty, then we can't really optimize anything...
	// so instead, we plop on a 1.0, to get things started.
	if (m_Top.IsEmpty())
		m_Top.AddTail(1.0);

	CDoubleList new_mul;
	double mul, div;
	bool used_for_future;
	POSITION p;
	int ret = 0;
	while (!m_Top.IsEmpty())
	{
		mul = m_Top.RemoveHead();
		p = m_Bot.GetHeadPosition();
		used_for_future = false;
		// search for a good number to divide by
		while (p != NULL)
		{
			div = mul / m_Bot.GetAt(p);
			if (!HOP_IS_BAD(div))
			{
				// found one, now add the new multiplication back to the
				// group of numbers to continue checking
				m_Top.AddTail(div);
				m_Bot.RemoveAt(p);
				used_for_future = true;
				ret = 1; // some optimization took place
				break;
			}
			m_Bot.GetNext(p);
		}
		// didn't find one, add it to the new_mul list
		if (!used_for_future)
			new_mul.AddTail(mul);
	}

	while (!new_mul.IsEmpty())
		m_Top.AddTail(new_mul.RemoveHead());

	return ret;
}

int CHopMulList::SplitNumbers()
{
	//
	//   this trick relies on the fact that if X is a "bad" number, then it
	//   is better to split X into two or more "good" numbers.  For example,
	//   if X is 1.0e20, then that is better represented as 1.0e10 * 1.0e10
	//   1.0e20 is bad, but 1.0e10 is good.
	//

	CDoubleList newTop;
	CDoubleList newBot;
	double val;
	int ret = 0;

	while (!m_Top.IsEmpty())
	{
		val = m_Top.RemoveHead();
		if (HOP_TOO_BIG(val))
		{
			// multiply the top by (val / BIGNUM) * BIGNUM
			newTop.AddTail(HOP_BIG_NUMBER);
			m_Top.AddTail(val / HOP_BIG_NUMBER);
			ret = 1;
		}
		else if (HOP_TOO_SMALL(val))
		{
			// multiply top and bottom by the same number
			newBot.AddTail(HOP_BIG_NUMBER);
			m_Top.AddTail(val * HOP_BIG_NUMBER);
			ret = 1;
		}
		else
			newTop.AddTail(val);
	}

	while (!m_Bot.IsEmpty())
	{
		val = m_Bot.RemoveHead();
		if (HOP_TOO_BIG(val))
		{
			// multiply the bottom by (val / BIGNUM) * BIGNUM
			newBot.AddTail(HOP_BIG_NUMBER);
			m_Bot.AddTail(val / HOP_BIG_NUMBER);
			ret = 1;
		}
		else if (HOP_TOO_SMALL(val))
		{
			// multiply the top and bottom by the same number
			newTop.AddTail(HOP_BIG_NUMBER);
			m_Bot.AddTail(val * HOP_BIG_NUMBER);
			ret = 1;
		}
		else
			newBot.AddTail(val);
	}

	while (!newTop.IsEmpty())
		m_Top.AddTail(newTop.RemoveHead());
	while (!newBot.IsEmpty())
		m_Bot.AddTail(newBot.RemoveHead());
	
	return ret;
}

int CHopMulList::GetFractionForm()
{
	//
	//  the nature of the optimizations will force the fraction to approach
	//  one of three different forms.
	//
	//  (1)   The final value is huge, and the fraction is composed of:
	//
	//                       big * big * big * big
	//                      -----------------------
	//                           small * small
	//
	//  (2)    The final value is tiny, and the fraction is composed of:
	//
	//                           small * small
	//                      -----------------------
	//                       big * big * big * big
	//
	//  (3)    The final value is "good", and the fraction is composed of:
	//
	//                            final value
	//                           -------------
	//                                 1
	//
	//  A form of 0 means that we haven't calculated the current form, and need
	//  to figure it out.

	if (m_FractionForm != 0)
		return m_FractionForm;

	// calculate fraction form
	// we must have the fraction in a fully optimized form :-(
	FullOptimize();

	if (m_Bot.GetCount() == 0)
		return (m_FractionForm = 3);

	if (m_Top.GetCount() == 1)
	{
		if (m_Top.GetHead() > m_Bot.GetHead())
			return (m_FractionForm = 1);
		else
			return (m_FractionForm = 2);
	}

	POSITION p = m_Top.GetHeadPosition();
	double val = 1.0;
	while (p != NULL)
	{
		val *= m_Top.GetNext(p);
		if (HOP_IS_BAD(val))
		{
			if (HOP_TOO_BIG(val))
				return (m_FractionForm = 1);
			else
				return (m_FractionForm = 2);
		}
	}

	// we should never really get to this point, but it's here just as a full
	// proof backup.  this is a sure-fire way to figure out what fraction it
	// is - although it should be avoided because it involves Calculate().
	val = Calculate();
	if (HOP_IS_BAD(val))
	{
		if (HOP_TOO_BIG(val))
			return (m_FractionForm = 1);
		else
			return (m_FractionForm = 2);
	}

	return (m_FractionForm = 3);
}
