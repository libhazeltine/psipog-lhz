#if !defined(AFX_PROMPTPROBDLG_H__12E80ACD_9E0C_411A_94DC_BAC588B95C39__INCLUDED_)
#define AFX_PROMPTPROBDLG_H__12E80ACD_9E0C_411A_94DC_BAC588B95C39__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PromptProbDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPromptProbDlg dialog

class CPromptProbDlg : public CDialog
{
// Construction
public:
	double m_Result;
	CPromptProbDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPromptProbDlg)
	enum { IDD = IDD_PROMPROB };
	DWORD	m_TotalOutcomes;
	DWORD	m_SuccessOutcomes;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPromptProbDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPromptProbDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROMPTPROBDLG_H__12E80ACD_9E0C_411A_94DC_BAC588B95C39__INCLUDED_)
