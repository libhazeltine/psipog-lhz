// PromptProbDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TrialProbability.h"
#include "PromptProbDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPromptProbDlg dialog


CPromptProbDlg::CPromptProbDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPromptProbDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPromptProbDlg)
	m_TotalOutcomes = 0;
	m_SuccessOutcomes = 0;
	//}}AFX_DATA_INIT
}


void CPromptProbDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPromptProbDlg)
	DDX_Text(pDX, IDC_EDIT1, m_TotalOutcomes);
	DDX_Text(pDX, IDC_EDIT2, m_SuccessOutcomes);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPromptProbDlg, CDialog)
	//{{AFX_MSG_MAP(CPromptProbDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPromptProbDlg message handlers

void CPromptProbDlg::OnOK() 
{
	UpdateData(TRUE);
	if (m_TotalOutcomes == 0)
	{
		AfxMessageBox("You can't have 0 total outcomes.");
		return;
	}
	if (m_SuccessOutcomes > m_TotalOutcomes)
	{
		AfxMessageBox("Successful outcomes must be smaller than total outcomes.");
		return;
	}

	m_Result = ((double)m_SuccessOutcomes) / ((double)m_TotalOutcomes);
	
	CDialog::OnOK();
}

BOOL CPromptProbDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_TotalOutcomes = 2;
	m_SuccessOutcomes = 1;
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
