// DoubleList.cpp: implementation of the CDoubleList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrialProbability.h"
#include "DoubleList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CDoubleList::CDoubleList()
{
	m_Default = 1.0;
}

CDoubleList::~CDoubleList()
{
	RemoveAll();
}

void CDoubleList::RemoveAll()
{
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		double *db = (double *)m_List.GetNext(p);
		delete db;
	}
	m_List.RemoveAll();
}

POSITION CDoubleList::AddHead(double db)
{
	double *ddb = new double;
	*ddb = db;
	return m_List.AddHead((void *)ddb);
}

POSITION CDoubleList::AddTail(double db)
{
	double *ddb = new double;
	*ddb = db;
	return m_List.AddTail((void *)ddb);
}

void CDoubleList::AddTail(CDoubleList &db)
{
	POSITION p = db.GetHeadPosition();
	while (p != NULL)
		AddTail(db.GetNext(p));
}

POSITION CDoubleList::GetHeadPosition()
{
	return m_List.GetHeadPosition();
}

double CDoubleList::GetNext(POSITION &pos)
{
	if (pos == NULL)
		return m_Default;
	return *((double *)m_List.GetNext(pos));
}

double CDoubleList::GetPrev(POSITION &p)
{
	if (p == NULL)
		return m_Default;
	return *((double *)m_List.GetPrev(p));
}

double CDoubleList::GetAt(POSITION pos)
{
	if (m_List.IsEmpty())
		return m_Default;
	return *((double *)m_List.GetAt(pos));
}

int CDoubleList::GetCount()
{
	return m_List.GetCount();
}

BOOL CDoubleList::IsEmpty()
{
	return m_List.IsEmpty();
}

double CDoubleList::RemoveHead()
{
	if (m_List.IsEmpty())
		return m_Default;
	double *ddb = (double *)m_List.RemoveHead();
	double ret = *ddb;
	delete ddb;
	return ret;
}

double CDoubleList::RemoveTail()
{
	if (m_List.IsEmpty())
		return m_Default;
	double *ddb = (double *)m_List.RemoveTail();
	double ret = *ddb;
	delete ddb;
	return ret;
}

void CDoubleList::SetAt(POSITION pos, double db)
{
	double *ddb = (double *)m_List.GetAt(pos);
	*ddb = db;
}

double CDoubleList::RemoveAt(POSITION p)
{
	if (m_List.IsEmpty())
		return m_Default;
	double *ddb = (double *)m_List.GetAt(p);
	m_List.RemoveAt(p);
	double ret = *ddb;
	delete ddb;
	return ret;
}

double CDoubleList::GetHead()
{
	return *(double *)m_List.GetHead();
}

POSITION CDoubleList::GetTailPosition()
{
	return m_List.GetTailPosition();
}

double CDoubleList::GetTail()
{
	return *(double *)m_List.GetTail();
}

void CDoubleList::Swap(CDoubleList &dbl)
{
	// a swap doesn't have to delete all the values, then recreate them with
	// new - we can just swap the actual pointers.

	CPtrList temp;
	// temp = dbl
	while (!dbl.m_List.IsEmpty())
		temp.AddTail(dbl.m_List.RemoveHead());
	// dbl = this
	while (!m_List.IsEmpty())
		dbl.m_List.AddTail(m_List.RemoveHead());
	// this = temp
	while (!temp.IsEmpty())
		m_List.AddTail(temp.RemoveHead());
}
