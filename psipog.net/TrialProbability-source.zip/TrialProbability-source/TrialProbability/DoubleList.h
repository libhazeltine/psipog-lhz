// DoubleList.h: interface for the CDoubleList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DOUBLELIST_H__060226CC_2CA1_4F0D_B6C7_D0D88CE24584__INCLUDED_)
#define AFX_DOUBLELIST_H__060226CC_2CA1_4F0D_B6C7_D0D88CE24584__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDoubleList  
{
public:
	void Swap(CDoubleList &dbl);
	double GetTail();
	double GetPrev(POSITION &p);
	POSITION GetTailPosition();
	void AddTail(CDoubleList &db);
	double GetHead();
	double RemoveAt(POSITION p);
	void SetAt(POSITION pos, double db);
	CDoubleList();
	double m_Default;
	double RemoveTail();
	double RemoveHead();
	BOOL IsEmpty();
	int GetCount();
	double GetAt(POSITION pos);
	double GetNext(POSITION &pos);
	POSITION GetHeadPosition();
	POSITION AddTail(double db);
	POSITION AddHead(double db);
	void RemoveAll();
	~CDoubleList();
private:
	CPtrList m_List;
};

#endif // !defined(AFX_DOUBLELIST_H__060226CC_2CA1_4F0D_B6C7_D0D88CE24584__INCLUDED_)
