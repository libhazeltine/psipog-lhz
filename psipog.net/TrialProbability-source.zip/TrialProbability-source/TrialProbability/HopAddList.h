// HopAddList.h: interface for the CHopAddList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOPADDLIST_H__8BF49A69_D175_4E8A_A30D_D83C883BE038__INCLUDED_)
#define AFX_HOPADDLIST_H__8BF49A69_D175_4E8A_A30D_D83C883BE038__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/*

	CDoubleList, CHopMulList, and CHopAddList are three classes I created in
	order to perform a huge number of operations (huge ops = hop) that need to
	be executed in an intelligent order to maintain percision.

	This is the problem - the formula for TrialProbability is:

                                          H     M
	                              S !   p     q
	                 odds  =   ---------------------
                                     H !  M !

			Where:
					S = number of trials
					H = number of hits
					M = number of misses (S - H)
					p = probability of success
					q = probability of failure (1 - p)

	Now normally, big deal... you just use double's and perform the math
	needed to figure out the problem.  However, in this case, we are dealing
	with large numbers of factorials and exponents - i.e., when multiplying all
	that crap out, you are going to get big numbers.

	For example, if you have 10000 trials, then S! turns out to be pretty
	freakin' big.

	The thing that bothered me was that I knew that the odds has to be between
	0.0 and 1.0 at the END of the calculation... so even though S! might be
	huge, it will get shrunken down by the other terms.

	I started by making some obvious optimizations to the formula... for
	example, instead of calculating S!, I would calculate S! UNTIL it reaches
	the start of H!.  Since H < S, then a lot of stuff will cancel out.  That
	saves a little bit of time.  Unfortunately, even with this optimization,
	things didn't work that much better.

	My second solution was to just store these huge numbers in memory as an
	array of DWORDS.  This turned out to be a huge hassel, and doing the math
	was a huge pain in the ass.  So screw that.

	My third solution came from noticing that if we expand the factorial and
	exponent into it's multiplication form, then we end up with a fraction
	like this:
	                     a * b * c * d * ... * x * y * z
	                   -----------------------------------
	                      aa * bb * cc * ... * yy * zz

	Basically, a long string of multiplications divided by another long string
	of multiplications.  So, if I multiply the top one by one, and when it
	starts to get too big, I divide it by one of the bottom numbers, then I
	can sort of work across intelligently and keep the percision I need.

	So I implemented that.

	It worked out great, and it calculated the large fractions exactly how I
	needed.  So that got me thinking a little bit .... >:-)

	If we want to do a range of values, then we need to add.

	My current solution could calculate the odds at ONE point, but if I wanted
	a range, then instead of calculating odds(X), I had to calculate:
	       odds(X) + odds(X + 1) + odds(X + 2) + .... + oods(X + n)
	This meant that my sweet ass optimization didn't work out perfectly...

	because how I had a string of multiplications divded by another string of
	multiplications... then a bunch of those units all added together.  I.e.,

		a * b * ... * z       ab * ac * .. az       more fractions...
	   -----------------  +  -----------------  +  ------------------- + ....
	    aa * bb .. * zz       ba * bc * .. bz       more fractions...

	
	Now, in my old system, it couldn't add all the odds(X)'s together because
	sometimes the odds at a specific X were waaaay too small.  However, over
	a range, those small elements would add up.  On top of that, it was really
	freakin' slow to calculate each odds(X) and add it up.

	So I developed another idea on the same concept of the previous idea...
	I can intelligently add the fractions together, and even perform some
	arithmatic and moving around of numbers to make things all work out at the
	end.

	Basically, the idea is:  if I know the original numbers, and the operations
	that need to be performed, then I should NEVER overflow or underflow.  When
	an over/underflow happens, I need to back up, and do some extra algebra
	to make sure things stay in a good range.

	So that's what my classes do.

	CDoubleList is just a list of double's.

	CHopMulList is a class that figures things out in the fraction form:

	                     a * b * c * d * ... * x * y * z       = m_Top
	                   -----------------------------------
	                      aa * bb * cc * ... * yy * zz         = m_Bot

	CHopAddList is a class that figures things out in the addition of
	fractions.  (Basically a list of CHopMulList's that should be added).

	Both CHopAddList and CHopMulList perform optimizations to keep the numbers
	in the best format.  The Calculate function will then calculate what the
	actual value is of the operation.
	
	If you have any questions, email me at peebrain@psipog.net

	- Sean Connelly, December 29, 2005

  */

#include "HopMulList.h"

class CHopAddList  
{
public:
	void Subtract(CHopAddList *al);
	void Add(CHopAddList *al);
	double Calculate();
	void Divide(CHopAddList *al);
	void Divide(CHopMulList *ml);
	void Divide(double db);
	void Multiply(CHopAddList *al);
	void Multiply(CHopMulList *ml);
	void Multiply(double db);
	int Optimize();
	int OldOptimize();
	void Subtract(CHopMulList *ml);
	void Subtract(double db);
	void Add(CHopMulList *ml);
	void Add(double db);
	CPtrList m_List;
	CHopAddList();
	virtual ~CHopAddList();
private:
	void AddSameFormMul(CHopMulList *m1, CHopMulList *m2, CHopMulList *topLeft, CHopMulList *topRight, CHopMulList *bot);
	void CombineLikeForms(CHopAddList *addwhat, CHopAddList *newList);
};

#endif // !defined(AFX_HOPADDLIST_H__8BF49A69_D175_4E8A_A30D_D83C883BE038__INCLUDED_)
