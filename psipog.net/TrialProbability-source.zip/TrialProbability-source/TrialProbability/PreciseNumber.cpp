// PreciseNumber.cpp: implementation of the CPreciseNumber class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrialProbability.h"
#include "PreciseNumber.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPreciseNumber::CPreciseNumber()
{
	Set(0.0);
}

CPreciseNumber::CPreciseNumber(double val)
{
	Set(val);
}

CPreciseNumber::CPreciseNumber(CPreciseNumber &num)
{
	Set(num);
}

CPreciseNumber::~CPreciseNumber()
{

}

void CPreciseNumber::Set(double val)
{
	m_MulList.RemoveAll();
	m_MulList.AddTail(val);
	m_Type = 0;
}


void CPreciseNumber::Set(CPreciseNumber &num)
{
	m_MulList.RemoveAll();
	m_MulList.AddTail(num.m_MulList);
	m_Type = num.m_Type;
}


void CPreciseNumber::Multiply(double val)
{
	//
	//  this function is recursive, and actually optimizes the values quite
	//  a bit.  the nature of the function is to search for a location where
	//  it can stick val.  if it can't find a position, then it adds val to
	//  the end of the list.
	//
	//  the imporant part is that if it does find a good location, then it
	//  REMOVES that location from the list, and then calls Multiply again
	//  with the new value.  This starts a new search for a group.
	//  (EDIT: it no longer performs the actual recursive call, but it does
	//   the same thing by manipulating the variables in the loop).
	//
	//  here is a break down, for example.  suppose the list looks like this:
	//
	//    m_MulList = A * B * C * D
	//
	//  now we introduce the value E to the list.  it starts at the tail and
	//  works it's way to the head.  so it tries E * D to see if it's a good
	//  value.  in this example, let's assume that it's not.  so it tries
	//  E * C.  still a bad value.  then E * B.  here we find a good value.
	//
	//  so it removes B from the list, so that:
	//
	//    m_MulList = A * C * D
	//
	//  but immediately after, calls Multiply(E * B).  so the value of the
	//  entire list is maintained.  E * B is a good number, and the search
	//  starts again from the tail.  it checks to see if (E * B) * D is a good
	//  value.  it's not.  it checks for (E * B) * C.  which is a good value.
	//
	//  so it removes C from the list:
	//
	//    m_MulList = A * D
	//
	//  and calls: Multiply((E * B) * C).
	//
	//  this searchs D, fails, then A, fails.  since it can't find a location
	//  for the value, it adds it to the tail.  the final equation is:
	//
	//    m_MulList = A * D * ((E * B) * C)
	//
	//  which is the intention of the original multiplication.  however - the
	//  important part is that the grouping of (E * B) * C is actually ONE
	//  entry in m_MulList which is a good value.  all entries are maintained
	//  as good values, and reduced as much as possible in the process.
	//

	if (PN_TOO_BIG(val))
	{
		val = val * PN_BIG_NUMBER_INV; // multiply by the inverse of the big
		Multiply(val);                 // number (i.e., divide by big num),
		Multiply(PN_BIG_NUMBER);       // then re-multiply.
		return;
	}
	else if (PN_TOO_SMALL(val))
	{
		val = val * PN_SMALL_NUMBER_INV; // same strategy as above, but use a
		Multiply(val);                   // small number instead.
		Multiply(PN_SMALL_NUMBER);
		return;
	}

	//  the val of Multiply should never be a BAD value.  this is ensured by
	//  the recursive section below, however, if the user decides to send in
	//  a bad value as the starter value, then it needs to be split (above).

	double cur_val;
	POSITION p = m_MulList.GetTailPosition();
	while (p != NULL)
	{
		cur_val = m_MulList.GetAt(p) * val;
		if (!PN_IS_BAD(cur_val))
		{
			m_MulList.RemoveAt(p);
			//Multiply(cur_val); // recursive :-(
			//return;
			
			// originally had the function call itself, but this was simplified
			// to the following, which does the same:
			// (F.Y.I. avoiding recursion where possible speeds things up)
			val = cur_val;
			p = m_MulList.GetTailPosition();
			continue;
		}
		m_MulList.GetPrev(p);
	}
	m_MulList.AddTail(val);

	if (m_MulList.GetCount() == 1)
		m_Type = 0; // one entry, this is good! :-)
	else // it has more than one entry
	{
		cur_val = m_MulList.GetHead() * m_MulList.GetTail();
		if (PN_TOO_BIG(cur_val))
			m_Type = 1; // too big
		else
			m_Type = 2; // too small
	}
}

void CPreciseNumber::Multiply(CPreciseNumber &num)
{
	POSITION p = num.m_MulList.GetHeadPosition();
	while (p != NULL)
		Multiply(num.m_MulList.GetNext(p));
}

void CPreciseNumber::Divide(double val)
{
	Multiply(1.0 / val);
}

void CPreciseNumber::Divide(CPreciseNumber &num)
{
	POSITION p = num.m_MulList.GetHeadPosition();
	while (p != NULL)
		Divide(num.m_MulList.GetNext(p));
}

void CPreciseNumber::Add(double val)
{
	CPreciseNumber n(val);
	Add(n);
}

void CPreciseNumber::Add(CPreciseNumber &num)
{
	CPreciseNumber n1(num);
	CPreciseNumber n2(*this);

	//
	//  the idea is that there are nine cases, based on the type of n1 and n2.
	//  if we can't find a good case, then we just factor out the addition.
	//
	//  result = n1 + n2
	//  result = n2 * (n1 / n2 + 1)   better for us because Multiply works good
	//
	//  since we have the Multiply function to keep things pretty on that end,
	//  it's beneficial to send things through there.  that's the goal of
	//  factoring.  after we factor, we check to see if adding 1.0 to the
	//  result will actually make a "difference".  I.e., if the number is
	//  a bagillion million, then adding 1 really doesn't do anything, so
	//  just toss it out the window.  on the other hand, if the number is
	//  really tiny, like 0.000000000000000000000000000000000000000000000001,
	//  then adding 1.0 to it will really kill the percision... so just admit
	//  it and calculate it out.
	//

	// X + 0 = X
	// first check to see if either term is 0.0
	if (n1.m_Type == 0)
	{
		if (n1.m_MulList.GetHead() == 0.0)
		{
			Set(n2);
			return;
		}
	}
	if (n2.m_Type == 0)
	{
		if (n2.m_MulList.GetHead() == 0.0)
		{
			Set(n1);
			return;
		}
	}

	if (n1.m_Type != 0 && n2.m_Type != 0)
	{
		//  if we don't have any "good" numbers, then we can create one.
		//  result = n1 + n2             = bad + bad
		//  result = n2 * (n1 / n2 + 1)  = bad * (bad / bad + good)
		n1.Divide(n2);
		n1.Add(1.0);
		Set(n1);
		Multiply(n2);
		return;
	}

	if (n1.m_Type == 0 && n2.m_Type == 0)
	{
		//
		//  this case is great, because it means we can actually perform a
		//  precise addition :-).  first, we try to add.  if we get a bad
		//  value, then we just do some basic algebra to maintain it's goodness
		//
		double new_val = n1.m_MulList.GetHead() + n2.m_MulList.GetHead();
		if (PN_TOO_BIG(new_val))
		{
			//  result = n1 + n2
			//         = 2 * ( (n1 * 0.5) + (n2 * 0.5) )
			new_val = (n1.m_MulList.GetHead() * 0.5) + (n2.m_MulList.GetHead() * 0.5);
			Set(new_val);
			Multiply(2.0);
		}
		else if (PN_TOO_SMALL(new_val))
		{
			// result = n1 + n2
			//        = 0.5 * ( (n1 * 2) + (n2 * 2) )
			new_val = (n1.m_MulList.GetHead() * 2) + (n2.m_MulList.GetHead() * 2);
			Set(new_val);
			Multiply(0.5);
		}
		else
		{
			// no problems performing addition - so do it :-)
			Set(new_val);
		}
		return;
	}

	// at this point, one of the n's must be type 0, and the other is 1 or 2

	if (n1.m_Type == 0 && n2.m_Type != 0)
		n1.m_MulList.Swap(n2.m_MulList);

	// now we've forced n2 to be type 0, and n1 to be either 1 or 2

	if (n2.m_MulList.GetHead() == 1.0)
	{
		if (n1.m_Type == 1) // so freaking big that +1 won't do anything
		{                   // might as well preserve the m_MulList
			Set(n1);
			return;
		}
		else // so freaking small that +1 will destroy it
		{    // don't need the tiny m_MulList, so just calculate it out
			Set(1.0 + n1.Calculate());
			return;
		}
	}
	else
	{
		// not 1.0 yet, so factor it out
		n1.Divide(n2);
		n1.Add(1.0);
		Set(n1);
		Multiply(n2);
		return;
	}
}

void CPreciseNumber::Subtract(double val)
{
	CPreciseNumber n(-val);
	Add(n);
}

void CPreciseNumber::Subtract(CPreciseNumber &num)
{
	CPreciseNumber n(num);
	n.Multiply(-1.0);
	Add(n);
}

double CPreciseNumber::Calculate()
{
	double ret = 1.0;
	POSITION p = m_MulList.GetHeadPosition();
	while (p != NULL)
		ret *= m_MulList.GetNext(p);
	return ret;
}
