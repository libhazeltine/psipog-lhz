// CalcProb.cpp: implementation of the CCalcProb class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrialProbability.h"
#include "CalcProb.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

