// PreciseNumber.h: interface for the CPreciseNumber class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PRECISENUMBER_H__82ADFE66_F6DB_4A9C_A3B6_34C2F36E9256__INCLUDED_)
#define AFX_PRECISENUMBER_H__82ADFE66_F6DB_4A9C_A3B6_34C2F36E9256__INCLUDED_

#include "DoubleList.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//
//  this class is used to calculate the odds.  it's purpose is to intelligently
//  perform operations to maintain as much precision as possible.
//
//  to read the theory behind the creation of this class, read the comments
//  above of OnCalculate in the file TrialProbabilityDlg.cpp
//
//  the basic idea is:
//   since were dealing with big numbers, it will be better to store a series
//   of multiplications and wait to calculate the result until we are ready for
//   the answer.  the list of multiplications is stored in m_MulList.  if we
//   maintain a clean list and perform operations intelligently to maintain
//   percision, then our final answer will be more accurate.
//
//  one important part is to track what the final number will be.  this is
//  maintained and stored in m_Type:
//    0 = the final value won't over/underflow the double's percision, and has
//        been calculated and stored as 1 entry in the m_MulList.  ideal.
//    1 = the final value can't be calculated because it will result in
//        OVERflow.  m_MulList has more than 1 entry.
//    2 = the final value can't be calculated because it will result in
//        UNDERflow.  m_MulList has more than 1 entry.
//

#define PN_TOO_BIG(x)        ((x) > 1.0e14 || (x) < -1.0e14)
#define PN_TOO_SMALL(x)      ((x) > -1.0e-14 && (x) < 1.0e-14 && (x) != 0.0)
#define PN_IS_BAD(x)         (PN_TOO_BIG(x) || PN_TOO_SMALL(x))
#define PN_BIG_NUMBER        (1.0e8)
#define PN_SMALL_NUMBER      (1.0e-8)
#define PN_BIG_NUMBER_INV    (1.0/PN_BIG_NUMBER)
#define PN_SMALL_NUMBER_INV  (1.0/PN_SMALL_NUMBER)

class CPreciseNumber  
{
public:
	double Calculate();
	void Subtract(CPreciseNumber &num);
	void Subtract(double val);
	void Add(CPreciseNumber &num);
	void Add(double val);
	void Divide(CPreciseNumber &num);
	void Divide(double val);
	void Multiply(CPreciseNumber &num);
	void Multiply(double val);
	CPreciseNumber(CPreciseNumber &num);
	void Set(CPreciseNumber &num);
	CPreciseNumber(double val);
	void Set(double val);
	CPreciseNumber();
	virtual ~CPreciseNumber();
private:
	int m_Type; // 0 = one item in list (good)
	            // 1 = list of huge numbers
	            // 2 = list of tiny numbers
	CDoubleList m_MulList;
};

#endif // !defined(AFX_PRECISENUMBER_H__82ADFE66_F6DB_4A9C_A3B6_34C2F36E9256__INCLUDED_)
