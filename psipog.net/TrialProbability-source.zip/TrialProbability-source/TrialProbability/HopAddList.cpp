// HopAddList.cpp: implementation of the CHopAddList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrialProbability.h"
#include "HopAddList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHopAddList::CHopAddList()
{

}

CHopAddList::~CHopAddList()
{
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetNext(p);
		delete ml;
	}
	m_List.RemoveAll();
}

void CHopAddList::Add(double db)
{
	CHopMulList *ml = new CHopMulList;
	ml->Multiply(db);
	Add(ml);	
}

void CHopAddList::Add(CHopMulList *ml)
{
	CHopMulList *nl = new CHopMulList;
	POSITION p = ml->m_Top.GetHeadPosition();
	while (p != NULL)
		nl->m_Top.AddTail(ml->m_Top.GetNext(p));
	p = ml->m_Bot.GetHeadPosition();
	while (p != NULL)
		nl->m_Bot.AddTail(ml->m_Bot.GetNext(p));
	m_List.AddTail((void *)nl);
}

void CHopAddList::Add(CHopAddList *al)
{
	POSITION p = al->m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)al->m_List.GetNext(p);
		Add(ml);
	}
}

void CHopAddList::Subtract(double db)
{
	Add(-db);
}

void CHopAddList::Subtract(CHopMulList *ml)
{
	CHopMulList *nl = new CHopMulList;
	POSITION p = ml->m_Top.GetHeadPosition();
	while (p != NULL)
		nl->m_Top.AddTail(ml->m_Top.GetNext(p));
	p = ml->m_Bot.GetHeadPosition();
	while (p != NULL)
		nl->m_Bot.AddTail(ml->m_Bot.GetNext(p));
	nl->Multiply(-1.0);
	m_List.AddTail((void *)nl);
}

void CHopAddList::Subtract(CHopAddList *al)
{
	POSITION p = al->m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)al->m_List.GetNext(p);
		Subtract(ml);
	}
}

void CHopAddList::Multiply(double db)
{
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetNext(p);
		ml->Multiply(db);
	}
}

void CHopAddList::Multiply(CHopMulList *ml)
{
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml2 = (CHopMulList *)m_List.GetNext(p);
		ml2->Multiply(ml);
	}
}

void CHopAddList::Multiply(CHopAddList *al)
{
	POSITION p = al->m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)al->m_List.GetNext(p);
		Multiply(ml);
	}
}

void CHopAddList::Divide(double db)
{
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetNext(p);
		ml->Divide(db);
	}
}

void CHopAddList::Divide(CHopMulList *ml)
{
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml2 = (CHopMulList *)m_List.GetNext(p);
		ml2->Divide(ml);
	}
}

void CHopAddList::Divide(CHopAddList *al)
{
	// MYTODO: no freakin' clue
	ASSERT(FALSE);
}

int CHopAddList::Optimize()
{
	return 1;
}

int CHopAddList::OldOptimize()
{
	if (m_List.GetCount() <= 1)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetHead();
		ml->FullOptimize();
		return 1;
	}

	// full optimize all the multiplications first
	// .... this could take a while...
	POSITION p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetNext(p);
		ml->FullOptimize();
	}
	return 0;

	//
	//  now, all multiplications are either in the form of:
	//      (1) big / small    or    (2) small / big
	//  we know this because all the multiplications are optimized fully.
	//  the formula we use for combining two fractions in addition is:
	//
	//    a       c       ad + cb
	//   ---  +  ---  =  ---------
	//    b       d          bd
	//
	//  with this formula, we notice it's better to pair up fractions in the
	//  same form.  then we get:
	//
	//     big.a         big.c        big.a * small.d + big.c * small.b
	//   ---------  +  ---------  =  -----------------------------------
	//    small.b       small.d               small.b * small.d
	//
	//  or
	//
	//    small.a       small.c       small.a * big.d + small.c * big.b
	//   ---------  +  ---------  =  -----------------------------------
	//     big.b         big.d                  big.b * big.d
	//
	//  since the big and small values are good, then big * small must be good.
	//  in both cases above, this leaves:
	//
	//   good + good         adding two good values together is easy - in the
	//  -------------        worst case of an over/underflow, we just have to
	//      b * d            factor out a good number to maintain a good value.
	//
	//  this optimization will translate the ENTIRE string of additions into
	//  one addition at the end (worst case):
	//
	//     big        small      and nothing more.  because if there is another
	//   -------  +  -------     fraction, then it can be grouped in with the
	//    small        big       one of it's same type, and combined into a new
	//                           fraction.
	//
	//  this final fraction can be reduced even further, using the same rule:
	//
	//    big.a        small.c       big.a * big.d + small.c * small.b
	//  ---------  +  ---------  =  -----------------------------------
	//   small.b        big.d                small.b * big.d
	//
	//  this allows the bottom to be reduced to good, and then split:
	//
	//                                big.a * big.d + small.c * small.b    
	//                               -----------------------------------
	//                                            good
	//
	//  split to:
	//                         big.a * big.d       small.c * small.b
	//                        ---------------  +  -------------------
	//                             good                  good
	//
	//  this new multiplication can then be re-optimized using the same method
	//  from the start.
	//
	//  eventually, the entire formula will be collapsed into one fraction,
	//  which is the best case.
	//

	CHopAddList add_big;
	CHopAddList add_small;
	CHopAddList add_good;
	
	// split the addition list into the 3 different groups
	p = m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetNext(p);
		switch (ml->GetFractionForm())
		{
		case 1: // big fraction
			add_big.Add(ml);
			break;
		case 2: // small fraction
			add_small.Add(ml);
			break;
		case 3: // good fraction
			add_good.Add(ml);
			break;
		default:
			ASSERT(FALSE);
			break;
		}
	}

	CHopAddList newList;
	
	if (add_big.m_List.GetCount() == 1 && add_small.m_List.GetCount() == 1)
	{
		CHopMulList *m1 = (CHopMulList *)add_big.m_List.GetHead();
		CHopMulList *m2 = (CHopMulList *)add_small.m_List.GetHead();
		CHopMulList topLeft, topRight, bot;
		AddSameFormMul(m1, m2, &topLeft, &topRight, &bot);
		topLeft.Divide(&bot);
		topRight.Divide(&bot);
		newList.Add(&topLeft);
		newList.Add(&topRight);
	}
	else
	{
		if (add_big.m_List.GetCount() > 1)
			CombineLikeForms(&add_big, &newList);
		if (add_small.m_List.GetCount() > 1)
			CombineLikeForms(&add_small, &newList);
	}

	if (add_good.m_List.GetCount() > 1)
	{
		CDoubleList newGood;
		POSITION last_p = NULL;
		bool added_to_new;
		double sub_add;
		while (!add_good.m_List.IsEmpty())
		{
			CHopMulList *delMe = (CHopMulList *)add_good.m_List.RemoveHead();
			double val = delMe->m_Top.GetHead();
			delete delMe;
			// find a group for add to be in
			// first check the last used group
			added_to_new = false;
			if (last_p != NULL)
			{
				sub_add = newGood.GetAt(last_p) + val;
				if (!HOP_IS_BAD(sub_add))
				{
					newGood.SetAt(last_p, sub_add);
					added_to_new = true;
				}
			}
			p = newGood.GetHeadPosition();
			while (p != NULL && !added_to_new)
			{
				sub_add = newGood.GetAt(p) + val;
				if (!HOP_IS_BAD(sub_add))
				{
					// found a good group!
					newGood.SetAt(p, sub_add);
					added_to_new = true;
					last_p = p;
					break;
				}
				newGood.GetNext(p);
			}
			// if we can't find a group, add one
			if (!added_to_new)
				newGood.AddTail(val);
		}

		while (!newGood.IsEmpty())
			newList.Add(newGood.RemoveHead());
	}
	else
		newList.Add(&add_good);


	// delete current list
	while (!m_List.IsEmpty())
	{
		CHopMulList *ml = (CHopMulList *)m_List.RemoveHead();
		delete ml;
	}

	// copy pointers from newList to m_List
	// make sure to remove pointers from newList so deconstructor doesn't
	// delete them.
	while (!newList.m_List.IsEmpty())
		m_List.AddTail(newList.m_List.RemoveHead());

	return 1;
}

void CHopAddList::CombineLikeForms(CHopAddList *addwhat, CHopAddList *newList)
{
	CHopMulList topLeft, topRight, bot;
	POSITION p = addwhat->m_List.GetHeadPosition();
	while (p != NULL)
	{
		CHopMulList *m1 = (CHopMulList *)addwhat->m_List.GetNext(p);
		if (p == NULL)
		{
			newList->Add(m1);
			break;
		}
		CHopMulList *m2 = (CHopMulList *)addwhat->m_List.GetNext(p);

		topLeft.m_Top.RemoveAll();
		topLeft.m_Bot.RemoveAll();
		topRight.m_Top.RemoveAll();
		topRight.m_Bot.RemoveAll();
		bot.m_Top.RemoveAll();
		bot.m_Bot.RemoveAll();

		AddSameFormMul(m1, m2, &topLeft, &topRight, &bot);

		if (topLeft.GetFractionForm() == 3 && topRight.GetFractionForm() == 3)
		{
			double topLeftVal = topLeft.m_Top.GetHead();
			double topRightVal = topRight.m_Top.GetHead();
			double newVal = topLeftVal + topRightVal;
			if (HOP_IS_BAD(newVal))
			{
				if (HOP_TOO_BIG(newVal))
				{
					newVal = (topLeftVal * 0.5) + (topRightVal * 0.5);
					newList->Add(newVal);
					newList->Add(newVal);
				}
				else // too small
				{
					topLeft.Divide(&bot);
					topRight.Divide(&bot);
					newList->Add(&topLeft);
					newList->Add(&topRight);
				}
			}
			else
			{
				bot.Divide(newVal);
				bot.Invert();
				newList->Add(&bot);
			}
		}
		else
		{
			topLeft.Divide(&bot);
			topRight.Divide(&bot);
			newList->Add(&topLeft);
			newList->Add(&topRight);
		}
		
	}
}

void CHopAddList::AddSameFormMul(CHopMulList *m1, CHopMulList *m2, CHopMulList *topLeft, CHopMulList *topRight, CHopMulList *bot)
{
	CHopMulList a;  //    a       c       ad + cb       topLeft + topRight
	CHopMulList b;  //   ---  +  ---  =  ---------  =  --------------------
	CHopMulList c;  //    b       d         bd                 bot
	CHopMulList d;

	POSITION p;

	p= m1->m_Top.GetHeadPosition();
	while (p != NULL)
		a.m_Top.AddTail(m1->m_Top.GetNext(p));
	p = m1->m_Bot.GetHeadPosition();
	while (p != NULL)
		b.m_Top.AddTail(m1->m_Bot.GetNext(p));
	p = m2->m_Top.GetHeadPosition();
	while (p != NULL)
		c.m_Top.AddTail(m2->m_Top.GetNext(p));
	p = m2->m_Bot.GetHeadPosition();
	while (p != NULL)
		d.m_Top.AddTail(m2->m_Bot.GetNext(p));

	bot->Multiply(&b);
	bot->Multiply(&d);

	topLeft->Multiply(&a);
	topLeft->Multiply(&d);

	topRight->Multiply(&c);
	topRight->Multiply(&b);
}

double CHopAddList::Calculate()
{
	// calculate the result of each multiplication
	POSITION p = m_List.GetHeadPosition();
	CDoubleList res_list;
	while (p != NULL)
	{
		CHopMulList *ml = (CHopMulList *)m_List.GetNext(p);
		res_list.AddTail(ml->Calculate());
	}

	// find a good way to combine the additions
	CDoubleList add_groups;
	double add;
	double sub_add;
	bool added_to_add;
	POSITION q;
	POSITION last_q;
	int made_a_change;

	while (1)
	{
		p = res_list.GetHeadPosition();
		last_q = NULL;
		made_a_change = 0;
		while (p != NULL)
		{
			add = res_list.GetNext(p);

			// find a group for add to be in
			// first check the last used group
			added_to_add = false;
			if (last_q != NULL)
			{
				sub_add = add_groups.GetAt(last_q) + add;
				if (!HOP_IS_BAD(sub_add))
				{
					add_groups.SetAt(last_q, sub_add);
					added_to_add = true;
					made_a_change = 1;
				}
			}
			q = add_groups.GetHeadPosition();
			while (q != NULL && !added_to_add)
			{
				sub_add = add_groups.GetAt(q) + add;
				if (!HOP_IS_BAD(sub_add))
				{
					// found a good group!
					add_groups.SetAt(q, sub_add);
					added_to_add = true;
					last_q = q;
					made_a_change = 1;
					break;
				}
				add_groups.GetNext(q);
			}
			// if we can't find a group, add one
			if (!added_to_add)
				add_groups.AddTail(add);
		}

		if (!made_a_change)
			break;
		res_list.RemoveAll();
		while (!add_groups.IsEmpty())
			res_list.AddTail(add_groups.RemoveHead());
	}

	double ret = 0.0;
	while (!res_list.IsEmpty())
		ret += res_list.RemoveHead();

	return ret;
}
