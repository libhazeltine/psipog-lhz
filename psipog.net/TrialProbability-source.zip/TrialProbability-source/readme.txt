Feel free to do whatever with this source... I don't really care.

Give credit if you want... but really... I don't care.  I'd be
genuinely surprised if someone actually USED this code.  Don't
ask me how it works.

It was built using Visual C++ 6.0... probably on Windows XP or
Windows ME... I think I had the latest VC++ service pack
installed, but I doubt that even matters.  The code is quite
plain.

- Sean (8/17/2012)