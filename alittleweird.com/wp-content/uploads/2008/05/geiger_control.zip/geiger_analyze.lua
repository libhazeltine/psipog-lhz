
filter_valid = true -- set to false to analyze all data, valid or not

-- step 1. load data into memory
cls()
print('Loading data...')
fp = io.open('geiger_data.csv', 'r')
if (fp == nil) then
	alert('Failed to find the data file:\n\n\tgeiger_data.csv\n\nDownload it from alittleweird.com and\nput it in the same directory as this script.', 'Fatal Error')
	return
end
dat = {}
dat_ts = {}
discard = 0
for line in fp:lines() do
	cpm = tonumber(string.sub(line, string.find(line, ';') + 1, -1))
	if (cpm > 0 or not filter_valid) then
		table.insert(dat, cpm)
		table.insert(dat_ts, tonumber(string.sub(line, 1, string.find(line, ';') - 1)))
	else
		discard = discard + 1
	end
end
fp:close()
print('Finished loading data')

if (#dat ~= 67141) then
	if (not confirm('Geiger data seems to be incorrect... continue anyways?')) then
		return
	end
end


-- step 2. analyze data
max_cpm = 0
max_when = 0
total = 0
cnt = {}
for i = 1, #dat do
	total = total + dat[i]
	cnt[dat[i]] = (cnt[dat[i]] or 0) + 1
	if (dat[i] > max_cpm) then
		max_cpm = dat[i]
		max_when = dat_ts[i]
	end
end

mode = {}
mode_size = 0
median = 0
median_total = 0
for i = 0, max_cpm + 1 do
	v = cnt[i] or 0
	if (mode_size == v) then
		table.insert(mode, i)
	elseif (v > mode_size) then
		mode = {i}
		mode_size = v
	end
	if (median_total >= 0) then
		median_total = median_total + v
		if (median_total > #dat / 2) then
			median_total = -1
			median = i
		end
	end
end

mode_str = ''
for k, v in pairs(mode) do
	if (mode_str ~= '') then
		mode_str = mode_str .. ', '
	end
	mode_str = mode_str .. v
end

print('Invalid entires: ' .. discard)
print('Valid entires: ' .. #dat, 'or roughly ' .. math.floor(100 * 60 * 60 * 24 * 7 / #dat) / 100 .. ' seconds between entries')
print('Maximum CPM: ' .. max_cpm .. ' on ' .. os.date('%c', max_when))
print('Average CPM: ' .. math.floor(1000 * total / #dat) / 1000)
print('Median CPM: ' .. median)
print('Mode CPM: ' .. mode_str .. ' (' .. mode_size .. ' occurrences)')
for i = 1, max_cpm + 1 do
	tot = 0
	for j = i, max_cpm do
		tot = tot + (cnt[j] or 0)
	end
	print('CPM = ' .. i .. ':', (cnt[i] or 0), 'CPM >= ' .. i .. ':', tot, 'or ' .. math.floor((1000000 * tot) / #dat) / 10000 .. '%')
end


-- step 3. draw pretty graph
start = 0
wnd = window.create{
		title = 'Geiger Graph - Click Window Area To Continue...',
		resize = false,
		width = 1200,
		height = 700,

		onclick = function(wnd, mse)
				start = start + wnd.height / 35 * wnd.width
				if (start > #dat) then
					wnd:close()
				else
					wnd:invalidate()
				end
			end,

		onpaint = function(wnd, pnt)
				here = start
				for y = 0, wnd.height - 1, 35 do
					for x = 0, wnd.width - 1 do
						if (dat[here]) then
							if (dat[here] == 0) then
								pnt:line(x, y + 35, x, y, rgb(255, 0, 0))
							else
								pnt:line(x, y + 35, x, y + 35 - dat[here], rgb(0, 0, 255))
							end
						end
						here = here + 1
					end
				end
			end,
	}

while window.getcount() > 0 do
	window.pumpmessages()
end
